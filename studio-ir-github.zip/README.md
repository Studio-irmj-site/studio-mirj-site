# Studio I&R — Página de Orçamento

Página pronta para publicar gratuitamente no **GitHub Pages**.

## Como publicar (sem precisar programar)

1. Crie uma conta em [github.com](https://github.com) (se ainda não tiver).
2. Clique no **+** no canto superior direito → **New repository**.
3. Dê um nome, por exemplo: `studio-ir` (pode ser qualquer nome, sem espaços).
4. Deixe como **Public** e clique em **Create repository**.
5. Na página do repositório recém-criado, clique em **Add file → Upload files**.
6. Arraste o arquivo `index.html` (desta pasta) para dentro da janela do navegador.
7. Clique em **Commit changes** (botão verde) para salvar.
8. Vá em **Settings** (aba no topo do repositório) → menu lateral **Pages**.
9. Em **Branch**, selecione `main` e a pasta `/ (root)` → clique em **Save**.
10. Aguarde 1–2 minutos. O GitHub vai mostrar o link do site, algo como:
    `https://SEUUSUARIO.github.io/studio-ir/`

Esse é o link que você vai usar no **Google Meu Negócio**, no campo "Site".

## Atualizando o site depois

Sempre que quiser mudar algo (preço, foto, horário):
1. Peça a atualização aqui na conversa e eu gero um novo `index.html`.
2. No repositório do GitHub, clique no arquivo `index.html` → ícone de lápis (editar) → ou **Add file → Upload files** novamente com o novo arquivo, substituindo o antigo.
3. Clique em **Commit changes** — o site atualiza sozinho em cerca de 1 minuto.

## Domínio próprio (opcional)

Se no futuro vocês comprarem um domínio (ex: `studioir.com.br`), dá pra apontar ele para esse mesmo GitHub Pages, mantendo tudo gratuito de hospedagem.
